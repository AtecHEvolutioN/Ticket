# Czech ticket selection and cart readiness

The monitor can inspect event pages. The source commands below add a
read-only Czech price catalog and an offline group planner. They do not
reserve tickets or run automatically from a watch. A separate experimental
[native cart command](native-cart-attempt.md) now connects one Find tickets action
to the durable journal; receipt verification remains unfinished. Android 0.7.0-test can save and
export [ticket preferences](ticket-preferences.md) for this planner.

## Inspect the configured selection choices

Build the current source, then run on a graphical desktop:

```bash
./target/release/ticket-watch cart-catalog --headed \
  --url https://www.ticketmaster.cz/event/korn-vstupenky/1472650657
```

For offline inspection, replace `--headed` with `--html captures/event.html`.
This needs no configuration file, API key, database, or Discord token. Saved HTML
has unverified transport and age; its embedded event identity must still match.
The live command requires a successful, current event document from the browser.
Access blocks stop inspection instead of producing prices from an error page.

The output distinguishes configured price choices, category and section IDs,
purchase limits, and the currently selected count. It explicitly reports
`configuration_only`: none of these establishes remaining stock, adjacent seats,
or a reservation. Amounts use integer minor units: 188900 means 1,889 CZK.
Each configured price's `total_minor` combines its per-ticket face value and
listed service/upsell charges; it is not a verified all-in group quote.
Handling fees are reported separately. This catalog covers primary configuration;
recognized resale listing rows are counted separately and excluded from it.
A price level called “Platinum” is not automatically the same
as the site's official Platinum ticket type. Duplicate rendered titles can group
multiple metadata types; their shared quantity control is counted once.

The catalog now exposes `event_start`, `event_time_zone` and `event_date_status`.
A single known performance time requires consistent offset-bearing metadata.
Unresolved or changed dates produce no usable performance instant; conflicting
exact timestamps are rejected. The timezone name remains source metadata. These
fields do not authenticate the age or source of an offline capture.
The [date validation report](evidence/service-and-date-validation-2026-11-10.json)
records successful saved-capture extraction for KoRn, Andrea Bocelli and Ross
Noble. A capture with an open filter panel and no visible bound event heading was
rejected; these are parser checks, not fresh availability observations.

## Evaluate an adjacent group

```bash
./target/release/ticket-watch cart-plan quotes.json
```

This command evaluates a supplied JSON request offline. It does not fetch quotes,
open a browser, write monitoring state, or create a cart. Its output is a decision
about the supplied claims, not proof that those claims came from Ticketmaster.
The Rust entry point is `cart::plan_json`; the typed request is `CartPlanRequest`.

The request must specify the quantity explicitly, or receive it from an explicit
`--preferences` document. Saved preferences default to two; a watch's minimum
quantity remains an alert filter and cannot supply this purchase instruction. Eligible groups
need that exact number of unique seats, site-confirmed adjacency when required, a
complete group total in CZK, and fresh matching event/session/document bindings.
Standing tickets and consecutive-looking seat numbers do not establish adjacency.
Unknown fees, stale quotes, category ranges, and quantity limits are insufficient.

Supply `intent.expected_event_start` and `snapshot.event_start` as RFC3339
timestamps with known offsets. The planner compares the exact UTC instants,
including fractional seconds. Missing dates produce at most a provisional result;
mismatched or malformed dates are refused. A matching event ID alone cannot prove
the quote is for the intended performance.

The cheapest eligible total can be called cheapest only within a complete search
for the requested quantity. Partial or unresolved search coverage produces at
most a provisional cheapest-observed group. Even a successful plan does not
authorize the reservation step. An optional maximum total can constrain selection;
the defaults are two adjacent seats and cheapest eligible total, without a specified cap.
Global defaults and per-event overrides can constrain ticket type, native category ID,
section and row. Every requested filter needs matching evidence. Disabling the
adjacency requirement permits exact seated groups in different rows or sections,
subject to the other filters; standing groups remain unsupported.

## Browser evidence still needed

[Section and seat inspection](seat-inspection.md) now reads explicit rendered
seat identities and an observed resale hover price without selecting the seat.
It keeps quantities, complete fees and adjacency unverified and does not feed
those display observations into the reservation planner.
The [section scanner](section-scans.md) can now discover resale seat IDs and
record displayed-price changes automatically within a selected section. Its
partial observations still do not establish a purchasable adjacent group.

Captured Czech pages for KoRn, Ross Noble, and Andrea Bocelli share the category
stepper and `findTicketsBtn` controls. Price and section filters are disabled until
a ticket type and quantity are chosen. The bundled Czech translations include a
non-adjacent-seat warning and hold-expiry text; translations alone prove neither
that a warning is currently displayed nor that a hold exists.

The first live control-inspection attempt on 2026-11-09 timed out during the
website's initial identification navigation, before changing any quantity.
A subsequent headed session reached the event. With network access then disabled,
a **demo quantity of one** enabled the native price and section filters. This was
local form research, not the user's purchase quantity or a ticket search.
The seating price filter displayed five choices (two at the same price):
2,361; 2,243; 2,125; 2,125; and 1,889 CZK. The section filter displayed
`1. POSCHODÍ` and `4. POSCHODÍ`. No `Najít vstupenky` action was submitted.
Opening a native filter changes the document's UI/fragment state; a future runner
must close it and revalidate the event before interpreting results.

The reusable [native controls command](cart-controls.md) now performs this demo
with networking disabled and restores zero quantity afterward. It validates both
native filter panels without activating Find tickets or selecting a filter. Its
isolated browser context closes when the command finishes; the output does not
configure a live purchase.

The [sanitized evidence](evidence/czech-cart-controls-2026-11-09.json) records
the successful offline UI inspection and three saved-capture catalog checks.
Raw HTML and session data remain private. Earlier headed access evidence is in
[the access diagnosis](czech-access.md). Access remains intermittent; neither
these observations nor the 198 passing Rust tests establish unattended production
readiness. Format checks and Clippy also passed for this source change.

The native adapter now uses a persistent session separate from the monitor's
short-lived page checks. The full cart flow requires:

1. Apply the explicitly requested quantity and validate the native exact-price
   filter and search order. Category minima overlap and cannot prove the cheapest
   available group.
2. Record an attempt durably **before** clicking Find tickets: the
   [public-source trace](czech-reservation-flow.md) confirms that this control can
   initiate a reservation. It is not a read-only availability probe.
3. Reject non-adjacent results and re-read prices and availability after any
   [manual verification pause](manual-intervention.md). No solver is connected.
4. Verify the resulting cart's event, quantity, seat grouping, complete price and
   actual hold/expiry. A selection counter is not a hold confirmation.
5. Treat a timeout after submission as an uncertain outcome. Reconcile the same
   session before another attempt; do not blindly retry, duplicate or renew holds.
6. Notify the configured Discord destination after verified availability or a
   verified hold, using public event links. Payment remains with the user.

The cart runner needs narrowly validated navigation rules for observed Czech cart
routes; the existing monitor's public-event policy remains in place. The
[durable attempt journal](cart-journal.md) now supplies separate storage, a
dispatch marker, idempotent outcomes and restart reconciliation. Its native
controller commits before Find tickets, but does not yet authenticate hold receipts.
The journal's `native_search` workflow now records requested filters before a
search that may reserve, keeping later seat/price/ranking evidence separate.
Recorded uncertain outcomes remain locked pending a separate reconciliation flow.
The planner and journal now bind supplied performance instants. Native extraction
and authentication of the receipt's date and other claims remain to be implemented.
Session ownership and manual pauses must not stall checks for unrelated watched
events.

Before production, validate this flow on more Czech layouts, exercise crash and
timeout recovery, and measure successful-check age, quote-to-action time, verified
hold time, and Discord acceptance latency. Source freshness, access restrictions,
and polling cadence prevent a guarantee of notification in the exact second stock
changes. Saved preferences now default to two adjacent tickets and allow an edited
quantity; no additional quantity answer is needed for the agreed first test.
